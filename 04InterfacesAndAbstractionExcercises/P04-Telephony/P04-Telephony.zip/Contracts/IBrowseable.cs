﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_Telephony.Contracts
{
    public interface IBrowseable
    {
        string Browse(string url);

    }
}
