﻿using P04_Telephony.Core;
using System;

namespace P04_Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
