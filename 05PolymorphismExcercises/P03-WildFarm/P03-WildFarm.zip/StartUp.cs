﻿using P03_WildFarm.Core;
using System;

namespace P03_WildFarm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine enngine = new Engine();
            enngine.Run();
        }
    }
}
