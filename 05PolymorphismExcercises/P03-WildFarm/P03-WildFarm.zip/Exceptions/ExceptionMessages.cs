﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public static string InvalidFoodTypeException = "{0} does not eat {1}!";
    }
}
