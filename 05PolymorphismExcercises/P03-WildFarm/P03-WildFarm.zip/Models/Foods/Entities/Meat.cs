﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_WildFarm.Models.Foods.Entities
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
