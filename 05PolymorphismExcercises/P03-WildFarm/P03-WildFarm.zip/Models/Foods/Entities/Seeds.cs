﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_WildFarm.Models.Foods.Entities
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
