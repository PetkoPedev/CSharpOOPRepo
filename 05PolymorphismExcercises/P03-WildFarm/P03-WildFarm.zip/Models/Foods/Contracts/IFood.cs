﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_WildFarm.Models.Foods.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
