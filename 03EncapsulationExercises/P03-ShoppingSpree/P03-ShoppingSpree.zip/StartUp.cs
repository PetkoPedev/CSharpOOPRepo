﻿using P03_ShoppingSpree.Core;
using System;

namespace P03_ShoppingSpree
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
